# README #

This project aims to create a GNU Radio module to use Link Quality Estimators, using RSSI and Holt-Winters methods.

It is in development, yet.

Please, contact me: wendley <at> gmail.com

Web page: http://dcc.ufmg.br/~wendley

### Main requirements ###
* GR-UHDGPS modified
* GR-Eventstream
* GR-foo