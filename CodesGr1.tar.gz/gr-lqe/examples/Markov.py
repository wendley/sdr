#Moving Average

import numpy as np
import math

# the time-series data.
y = [146, 96, 59, 133, 192, 127, 79, 186, 272, 155, 98, 219]

s1 = [1,2,3,4,5,6,7,8,9,10]
s2 = [3,5,2,4,9,1,7,5,9,1]


max_serie = max(serie)
min_serie = min(serie)
dife = max_serie - min_serie
tam_janela = round(math.sqrt(dife))

for i in len(serie):
    for j in tam_janela:
        if (serie[i] >= (min_serie + (j-1)*tam_janela)) and (serie[i]< (min_serie + j*tam_janela)):
            seq_estados[i] = j


# Vetor de probabilidades iniciais dos estados (vpi)
vpi= ((hist(seq_estados,tam_janela))/len(serie))'
#FIXME: histograma


# Gerando a transicao de estados - Matriz de transicao (mt)
ma = calcula_ma (tam_janela, seq_estados);



# Matriz de distribuicao estacionaria (mde)
% me=ma^50;       #matriz dos auto-vetores de ma.
% pn=(me(1,:))'  #vetor de probabilidades dos estados num tempo n>>1 qualquer.
#FIXME: matriz transpostas

ma_pred(:,1)= pih' # Passo nr. 1
[valor(1,1),pos(1,1)]=max(pih);
seq_estados(length(serie)+1)= pos(1,1)

ma_pred(:,2)= pih' * ma # Passo nr. 2
[valor(1,2),pos(1,2)]=max(ma_pred(:,2))
seq_estados(length(serie)+2)= pos(1,2)

for i=3 in 10: # Passos nr. 3 a 10
    ma_pred(:,i) = pih' * ma^i
    [valor(1,i),pos(1,i)]=max(ma_pred(:,i))
    seq_estados(length(serie)+i)= pos(1,i)


est = calMarkov(s1)
print est


def calcMarkov (serie):
   

    weights = np.repeat(1.0, window)/window
    sma = np.convolve(values, weights, 'valid')

    return sma
