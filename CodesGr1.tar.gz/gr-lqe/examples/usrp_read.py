#!/usr/bin/env python
#
# Copyright 2016 <Wendley S. Silva (http://github.com/wendley)>
#
# This file is a simple test to execute set_gain and get_gain from USRP/UHD. Modified from [1]
# [1] https://silentresearcher.wordpress.com/2013/07/17/how-to-read-usrp-parameters-using-python/
#
# Run this program using this commands on Linux:
# $ chmod +x usrp_read_program.py (only first time)
# $ ./usrp_read_program.py


from gnuradio import gr
from gnuradio import uhd

class usrp_read(gr.top_block):
      def __init__(self):
           gr.top_block.__init__(self)

           self.uhd_usrp_source = \
           uhd.usrp_source(device_addr="",stream_args=uhd.stream_args('fc32'))
           self.uhd_usrp_source.set_antenna("RX2", 0)
           self.uhd_usrp_source.set_samp_rate(1000000) #This sets the sampling rate to 1000000 i.e. 1MSPS
           self.uhd_usrp_source.set_gain(45) #This sets the gain to 45dB
           ganho = self.uhd_usrp_source.get_gain()
           print "Ganho: %d" %(int(ganho))
           treq = uhd.tune_request(2450000000) #This sets the center frequency to 2450000000 i.e. 2.45GHz
           self.uhd_usrp_source.set_center_freq(treq)

if __name__ == '__main__':
      tb = usrp_read()
      tb.run()
